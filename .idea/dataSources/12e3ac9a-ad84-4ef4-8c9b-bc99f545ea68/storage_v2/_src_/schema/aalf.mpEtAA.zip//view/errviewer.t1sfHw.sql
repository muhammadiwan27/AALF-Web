create definer = root@localhost view errviewer as
select `aalf`.`err`.`uid`     AS `uid`,
       `aalf`.`err`.`time`    AS `time`,
       `aalf`.`err`.`kode`    AS `kode`,
       `aalf`.`err`.`message` AS `message`,
       `aalf`.`err`.`userId`  AS `userId`,
       `aalf`.`err`.`payload` AS `payload`,
       `aalf`.`err`.`url`     AS `url`
from `aalf`.`err`
order by `aalf`.`err`.`uid` desc;

